import UIKit

var str = "Hello, playground"

//create an empty array - variable declaration
var someInts = [Int]()
print("someInts is of type [Int] with \(someInts.count) items.")

//add an element to this empty array
someInts.append(3)

//empty the array again but it's still an int array, bcz we declare it before
someInts = []

//creating an array with a default value
var threeDoubles = Array (repeating: 0.1, count: 3)
var anotherThreeDoubles = Array (repeating: 2.5, count: 3)
var sixDouble = threeDoubles + anotherThreeDoubles

//creating an array with an array literal
var shoppingList: [String] = ["eggs", "milk"]
//simpler
var anotherShoppingList = ["eggs", "milk"]

print("the shopping list contains \(shoppingList.count) items.")

//.isEmpty
if shoppingList.isEmpty{
    print("the shopping list is empty")
}else{
    print("the shopping list is not empty")
}

// add
 shoppingList.append("flour")
print("the shopping list contains \(shoppingList.count) items.")

shoppingList += ["salt"]
print("the shopping list contains \(shoppingList.count) items.")

//sequence number
var firstItem = shoppingList[0]
 shoppingList [1...3]

//insert & remove
shoppingList.insert("Syrup", at: 0)
shoppingList.remove(at: 0)

let theRemovedItem = shoppingList.remove(at: 0)

//print
for item in shoppingList{
    print(item)
}


