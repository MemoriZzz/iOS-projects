// codes that wrote by a smart grogrammer
import UIKit



// outcome
var str = "look what can i do"



// calculate
123*456



// there are 4 types_of_variable in swift (Int Double Bool String)
var my_favorate_number : Int = 4
var cost_of_this_coffee : Double = 4.25
var hungry_or_not : Bool = true
var my_name : String = "Rachel"



// Want to change the value of a variable, dot't have to use "var" and type_name again.
my_name = "Rach"



// there are also 4 types in constant in swift (Int Double Bool String)
// using constant is faster than using variable
let graviation_constant : Int = 10
let pi: Double = 3.14
let you_can_speak_dutch : Bool = false
let your_real_name : String = "Wang Yuqing"



// actually, you don't have to write ": type" at all, cause 10 or 3.14 or false or "Wangyuqing" is enough to tell your IDE witch type you wanna choose
var your_name = "Wangyuqing"
let your_bf_name = "Wuchushu"



// comparision oprator
var WeChat = 9
var QQ = 5
var Facebook = 1
WeChat > QQ
WeChat < Facebook
WeChat == (QQ+Facebook*4)
WeChat > QQ || WeChat < Facebook
WeChat > QQ && WeChat < Facebook



// if else
if (WeChat < Facebook)
{
    WeChat = WeChat - 1
}
else
{
    WeChat = WeChat + 1
}



// built-in functions
print(WeChat)



//while
var seconds_left = 3
while (seconds_left>0)
{
 print(seconds_left)
    seconds_left = seconds_left - 1
}
print ("blast off")

var donuts = 6
while (donuts>0)
{
    print("you got ",donuts," donuts left!" )
    donuts = donuts - 1
    print("you ate one donut!")
}
print ("there are no donuts")


// break
var goofing_off_time = 10
var boss_coming = 0
while (goofing_off_time > 0)
{
    print("goofing time!")
    boss_coming = boss_coming + 1
    goofing_off_time = goofing_off_time - 1
    
    if (boss_coming == goofing_off_time)
    {
        break;
        
    }
    
}
print ("opps")



// continue: i don't like seven, the number, so i won't print it.
var number = 0
while (number <= 10)
{
    if(number == 7)
    {
        number = number + 1
        continue
    }
    print (number)
    number = number + 1
}



var message = "hello world" // message 是容器，后面的字符串是容器中的内容



