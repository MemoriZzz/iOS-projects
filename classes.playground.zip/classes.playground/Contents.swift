import UIKit

var str = "Hello, playground"


// an example
struct Resolution{
    var width = 0
    var hight = 0
}

class VideoMode{
    var resolution = Resolution()
    var interlaced = false
    var frameRate = 0.0
    var name: String?
}

let someResolution = Resolution()
let someVideoMode = VideoMode()

print("the width of someResolution is \(someResolution.width)")
print("the width of someVideoMode is \(someVideoMode.resolution.width)")

someVideoMode.resolution.width = 1280
print("the width of someVideoMode now is \(someVideoMode.resolution.width)")
